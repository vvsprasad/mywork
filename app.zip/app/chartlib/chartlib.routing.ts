import { Routes } from '@angular/router';

import { ChartlibComponent } from './chartlib.component';

export const ChartlibRoutes: Routes = [{
  path: '',
  component: ChartlibComponent
}];
