﻿import { Component, OnInit } from '@angular/core';
import {Location, LocationStrategy, PathLocationStrategy} from '@angular/common';
import {Router} from '@angular/router';

@Component({
    selector: 'app-dashboard',

    templateUrl: './dashboard.component.html',
    styleUrls: ['./dashboard.component.scss']
})
export class DashboardComponent implements OnInit {

    dropdownList = [];
    selectedItems = [];
    dropdownSettings = {};
    //tempItem = {};
    tempRows = [];
    rows = [];
    temp = [];
    patientList = [];
    selected = [];
    selectedRows = [];
// Added by Mahesh for Scrolling to div
    location;
    router: Router;
    constructor(location: Location,_router: Router){
         this.location = location;
         this.router=_router;
    }
    route(id,param){
        debugger;
        sessionStorage.setItem('type',param);
        this.router.navigateByUrl('/administration/'+id);
    }
   // Addition ended
    ngOnInit() {

        this.fetch((data) => {
            this.temp = data;

            this.rows = data;
            console.log("this.rows",this.rows)

            for (var i = 0; i < this.rows.length; i++) {
                this.patientList.push({ "id": this.rows[i].pid, "itemName": this.rows[i].project });
            }

            this.dropdownList = this.patientList;

        });

       
        
     
     
       
       // console.log("this.selectedItems", this.selectedItems);
        this.dropdownSettings = {
            singleSelection: false,
            text: "Patient",
            selectAllText: 'Select All',
            unSelectAllText: 'UnSelect All',
            enableSearchFilter: true,
            classes: "myclass custom-class"
        };
    }

   
 


    onItemSelect(item: any) {
        this.rows = [];
        this.selectedRows = [];
        for (var i = 0; i < this.selectedItems.length; i++) {
           this.selectedRows.push(this.temp.filter(p => p.pid === this.selectedItems[i].id)[0]);
           // console.log("inside forloop", x.filter(p => p.pid === y[i].id)[0])
        }
        //  console.log();
        this.rows = this.selectedRows;
        console.log(this.rows);

    }
    OnItemDeSelect(item: any) {
      //  console.log(item);
      //  console.log(this.selectedItems);
    }
    onSelectAll(items: any) {
       // console.log(items);
    }
    onDeSelectAll(items: any) {
       // console.log(items);
    }

  


   



    // project table
    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/projects.json`);
        req.onload = () => {
            cb(JSON.parse(req.response));
        };
        req.send();
    }
    updateFilter(event) {
        console.log(event.target.value);
        const val = event.target.value.toLowerCase();

        // filter our data
        const temp = this.temp.filter(function (d) {
            return d.project.toLowerCase().indexOf(val) !== -1 || !val;
        });

        // update the rows
        this.rows = temp;
    }


    //by selecting the row it displays the selected row we romeved

    //onSelect({ selected }) {
    //    console.log('Select Event', selected, this.selected);

    //    this.selected.splice(0, this.selected.length);
    //    this.selected.push(...selected);
    //}

    //onActivate(event) {
    //    console.log('Activate Event', event);
    //}



     

}
