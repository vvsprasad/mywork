﻿import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MdDialog, MdDialogRef, MdDialogConfig, MdButton, MdButtonModule } from '@angular/material';
import { ActivatedRoute } from '@angular/router';

import { MdGridListModule } from '@angular/material';
import { MdSelectModule } from '@angular/material';



@Component({
    selector: 'history',
    templateUrl: './history.component.html',
    styleUrls: ['./StyleSheet1.scss']
})


export class HistoryComponent implements OnInit {

    dialogRef: MdDialogRef<any>;








    basicRowHeight = 30;
    fixedCols = 12;
    fixedRowHeight = 100;
    ratioGutter = 1;
    fitListHeight = '200px';
    ratio = '1:1';






    pid: string;
    patientId: string;
    isRequired = false;
    isDisabled = false;
    currentDrink: string;
    patientName: string;
    pn: string;


    pInfo = [];

    temp = [];
    rows = [];



    //dialogRef: MdDialogRef<JazzDialogComponent>;
    //lastCloseResult: string;
    //config: MdDialogConfig = {
    //    disableClose: false,
    //    width: '',
    //    height: '',
    //    position: {
    //        top: '',
    //        bottom: '',
    //        left: '',
    //        right: ''
    //    }
    //};

    //dialogRef1: MdDialogRef<NComponent>;
    //lastCloseResult1: string;
    //config1: MdDialogConfig = {
    //    disableClose: false,
    //    width: '',
    //    height: '',
    //    position: {
    //        top: '',
    //        bottom: '',
    //        left: '',
    //        right: ''
    //    }
    //};


    //constructor(public dialog: MdDialog, public dialog1: MdDialog,private _route: ActivatedRoute)  {

    //}


    constructor(public dialog: MdDialog, private _route: ActivatedRoute) { }

    open(key) {
        console.log("key", key);
        this.dialogRef = this.dialog.open(dialogsMap[key]);

        this.dialogRef.afterClosed().subscribe(result => {
            this.dialogRef = null;
        });
    }

    // -----
    isChecked: boolean = true;

    toggle(): void {
        alert('ddd');
        this.isChecked = !this.isChecked;
    }

    saveData() {
        alert('save ');
    }

    ngOnInit(): void {

        let id = +this._route.snapshot.params['pid'];
        this.patientId = `${id}`;

        this.fetch((data) => {
            this.temp = data;

            this.rows = data;

            this.pInfo = this.rows.filter(item => item.pid == parseInt(this.patientId))[0];
        });





    }






    // project table
    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/projects.json`);
        req.onload = () => {
            cb(JSON.parse(req.response));
        };
        req.send();
    }




    //open(setup, frequency) {
    //    this.dialogRef = this.dialog.open(JazzDialogComponent, this.config);
    //    this.dialogRef.afterClosed().subscribe(result => {
    //        this.lastCloseResult = result;
    //        this.dialogRef = null;
    //    });
    //}



    //pop() {
    //    this.dialogRef1 = this.dialog1.open(NComponent, this.config1);
    //    this.dialogRef1.afterClosed().subscribe(result => {
    //        this.lastCloseResult1 = result;
    //        this.dialogRef1 = null;
    //    });
    //}
}
//@Component({
//    selector: 'app-jazz-dialog',
//    templateUrl: './HTMLpage1.html'
//})
//export class JazzDialogComponent {
//    currentDrink: string;
//    startAt: string;
//    hello: string;

//    constructor(public dialogRef: MdDialogRef<JazzDialogComponent>) { }
//    drugs = [{

//        Route: 'A'
//    }, {
//        Route: 'B'
//    }, {
//        Route: 'C'
//    }, {
//        Route: 'D'
//    }
//    ];
//}


@Component({
    selector: 'editDialog',
    template: `
  <h2>Second dialog! - edit Dialog</h2>
 <p>Second dialog!</p>
  <button md-raised-button (click)="dialogRef.close()">Close</button>`
})
export class EditDialog {
    constructor(public dialogRef: MdDialogRef<any>) { }
}

@Component({
    selector: 'addDailyDialog',
    templateUrl: './addDaily.html'

})
export class AddDailyDialog {

    EndAt: string;
    startAt: string;
    constructor(public dialogRef: MdDialogRef<any>) { }


}


@Component({
    selector: 'addMonthlyDialog',
    templateUrl: './addMonthly.html'
})
export class AddMonthlyDialog {
    selectedValue1: string;
    selectedValue2: string;
    selectedValue3: string;
    startAt: string;
    EndAt: string;
    EndAtPicker: string;

    days = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30];
    weeks = ["FIRST", "SECOND", "THIRD", "FOURTH"];
    weekDays = ["SUNDAY", "MONDAY", "TUESDAY", "WEDNESDAY", "THURSDAY", "FRIDAY", "SATURDAY"];

    constructor(public dialogRef: MdDialogRef<any>) { }
    dateClicked() {
        //console.log('date clicked',document.getElementById('cdk-overlay-1').style.top);
        let elements = document.getElementsByClassName('cdk-overlay-pane');
        for (let i = 1; i <= elements.length; i++) {
            let el = <HTMLElement>elements[i];
            if (el !== undefined){
                el.style.top = 'calc(' + el.style.top + ' - ' + '350px)';
            }
        }
    }
}

@Component({
    selector: 'addWeeklyDialog',
    templateUrl: './HTMLpage1.html'
})
export class AddWeeklyDialog {
    startAt: string;
    constructor(public dialogRef: MdDialogRef<any>) { }
}


const dialogs = [AddDailyDialog, AddWeeklyDialog, AddMonthlyDialog, EditDialog];
const dialogsMap = {
    'addMonthly': AddMonthlyDialog,
    'addWeekly': AddWeeklyDialog,
    'addDaily': AddDailyDialog,
    'edit': EditDialog
}


//@Component({


//})


//export class NComponent {
//    constructor(public dialogRef1: MdDialogRef<NComponent>) { }

//    D8: string;
//    startAt: string;

//    drugs = [{

//        Route: 'MEDICATION HELD'
//    }, {
//        Route: 'HIU'
//    }, {
//        Route: 'DISCHARGED'
//    }, {
//        Route: 'D'
//    }
//    ];
//}




