﻿
import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

import { MdIconModule, MdCardModule, MdButtonModule, MdListModule, MdProgressBarModule, MdMenuModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';

import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {
    FullscreenOverlayContainer,
    MaterialModule,
    MdNativeDateModule,
    MdSelectionModule,
    OverlayContainer
} from '@angular/material';



import { AgmCoreModule } from '@agm/core';
import { ChartsModule } from 'ng2-charts/ng2-charts';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';


import { HistoryComponent, AddDailyDialog, AddWeeklyDialog, AddMonthlyDialog, EditDialog} from './history.component';
import { HistoryRoutes } from './history.routing';
 

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(HistoryRoutes),
        MdIconModule,
        MdCardModule,
        MdButtonModule,
        MdListModule,
        ChartsModule,
        FlexLayoutModule,
        NgxDatatableModule,
        MdProgressBarModule,
        MdMenuModule,
        MaterialModule,
        MdNativeDateModule,
        MdSelectionModule,
        FormsModule,
        ReactiveFormsModule,
         




        AgmCoreModule.forRoot({ apiKey: 'AIzaSyB3HQ_Gk_XRt6KitPdiHQNGpVn0NDwQGMI' })
    ],
    providers: [
        { provide: OverlayContainer, useClass: FullscreenOverlayContainer }
    ],
    declarations: [HistoryComponent, AddDailyDialog, AddWeeklyDialog, AddMonthlyDialog, EditDialog],
    entryComponents: [AddDailyDialog, AddWeeklyDialog, AddMonthlyDialog, EditDialog]
})

export class HistoryModule { }
