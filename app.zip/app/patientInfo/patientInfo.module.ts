﻿import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { HttpModule } from '@angular/http';
import { CommonModule } from '@angular/common';
import {
    FullscreenOverlayContainer,
    MaterialModule,
    MdNativeDateModule,
    MdSelectionModule,
    OverlayContainer
} from '@angular/material';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FlexLayoutModule } from '@angular/flex-layout';
import { PatientInfoComponent, JazzDialogComponent, NComponent } from './patientInfo.component';
import { PatientInfoRoutes } from './patientInfo.routing';
 
  


@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(PatientInfoRoutes),
        MaterialModule,
        MdNativeDateModule,
        MdSelectionModule,
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        FlexLayoutModule,
         
    ],
    providers: [
        { provide: OverlayContainer, useClass: FullscreenOverlayContainer }
    ],
    declarations: [PatientInfoComponent, JazzDialogComponent, NComponent],
    entryComponents: [JazzDialogComponent, NComponent]
    
})

export class PatientInfoModule { }
