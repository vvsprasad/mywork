﻿import { Component } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MdDialog, MdDialogRef, MdDialogConfig } from '@angular/material';
import {MdAutocompleteModule} from '@angular/material';
import 'rxjs/add/operator/startWith';
import 'rxjs/add/operator/map';

@Component({
    templateUrl:'./editAssignments.component.html'

})

export class EditAssignmentComponent{
    
    rows = [];
    selected = [];
    temp = [];
    nurse: string;
    aide: string;
    isRequired = false;
    isDisabled = false;
    hideTable: boolean = false; 

    constructor(public dialog: MdDialog) {
        this.fetch((data) => {
            this.rows = data;
            this.temp = data;
        });
    }



    

    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/company.json`);

        req.onload = () => {
            cb(JSON.parse(req.response));
        };

        req.send();
    }

    onSelect({ selected }) {
        console.log('Select Event', selected, this.selected);

        this.selected.splice(0, this.selected.length);
        this.selected.push(...selected);
    }

    onActivate(event) {
        console.log('Activate Event', event);
    }

   

    update() {
        this.selected = [this.rows[1], this.rows[3]];
    }

    remove() {
        this.selected = [];
    }
    updateFilter(event) {
        console.log(event.target.value);
        const val = event.target.value.toLowerCase();

        // filter our data
        const temp = this.temp.filter(function (d) {
            return (d.patientname.toLowerCase().indexOf(val) !== -1 || d.nurse.toLowerCase().indexOf(val) !== -1 ||d.aide.toLowerCase().indexOf(val)!==-1)|| !val;
        });

        // update the rows
        this.rows = temp;
        console.log('hello',this.rows)
    }

    //hideEditAssignmentTable(event) {
    //    this.hideTable = true;
    //}
    //showEditAssignmentTable(event) {
    //    this.hideTable = false;
    //}




    dialogRef: MdDialogRef<JazzDialogComponent>;
    lastCloseResult: string;
    config: MdDialogConfig = {
        disableClose: false,
        width: '',
        height: '',
        position: {
            top: '',
            bottom: '',
            left: '',
            right: ''
        }
    };



    open() {
        this.dialogRef = this.dialog.open(JazzDialogComponent, this.config);
        this.dialogRef.afterClosed().subscribe(result => {
            this.lastCloseResult = result;
            this.dialogRef = null;
        });
    }
     
}


@Component({
    selector: 'app-jazz-dialog',
    templateUrl: './HTMLpage1.html',
    providers: [EditAssignmentComponent]
})
export class JazzDialogComponent {
    
    nurseCtrl: FormControl;
    filteredNurses: any;

    aideCtrl: FormControl;
    filteredAides: any;

    rows = [];
    n = [];
    nurse: string;
    aide:string;

    isRequired = false;
    isDisabled = false;

    constructor(public dialogRef: MdDialogRef<JazzDialogComponent>, private EditAssignmentComponent: EditAssignmentComponent) {

     
this.nurseCtrl = new FormControl();
      this.aideCtrl = new FormControl();
        this.EditAssignmentComponent.fetch((data) => {
            this.rows = data;
            this.Init();
       });
    }
Init() { 
    this.filteredNurses = this.nurseCtrl.valueChanges
        .startWith(null)
        .map(name => this.filterNurses(name));
    this.filteredAides = this.aideCtrl.valueChanges
        .startWith(null)
        .map(name => this.filterAides(name));    
   }

  filterNurses(val: string) {
    return val ? this.rows.filter(s => new RegExp(`^${val}`, 'gi').test(s.nurse||''))
               : this.rows;
  }

  filterAides(val: string) {
    return val ? this.rows.filter(s => new RegExp(`^${val}`, 'gi').test(s.aide||''))
               : this.rows;
  }
}