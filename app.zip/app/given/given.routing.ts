﻿import {Routes } from '@angular/router';

import { GivenComponent } from './given.component'; 

export const GivenRoutes: Routes = [{
    path: '',
    component: GivenComponent
}];




