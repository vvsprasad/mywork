﻿import { Component, OnInit } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MdDialog, MdDialogRef, MdDialogConfig } from '@angular/material';
import { ActivatedRoute} from '@angular/router'
 
@Component({

    selector:'wii-html',

    templateUrl:'./wii.component.html',
    styleUrls: ['./wi.scss']
})


export class HiComponent implements OnInit {
    project: string;
    date: string;
    patientName: string;
    patientId: string;
    isRequired = false;
    isDisabled = false;
    currentDrink: string;
    temp = [];
    rows = [];
    pInfo = [];
    smflag = [];
    SMInfo = [];
    odflag = [];
    ODInfo = [];
    prnflag = [];
    PRNInfo = [];

    ngOnInit(): void {
        let id = +this._route.snapshot.params['pid'];
        let path=sessionStorage.getItem('type');
        this.patientId = `${id}`;

        this.fetch((data) => {
            this.temp = data;

            this.rows = data;
            for(var j=0;j<this.rows.length;j++){

                if(this.rows[j].one == "fiber_manual_record" || this.rows[j].two == "fiber_manual_record" || this.rows[j].three == "fiber_manual_record" || this.rows[j].four == "fiber_manual_record" || this.rows[j].five == "fiber_manual_record" || this.rows[j].six == "fiber_manual_record")
                    this.smflag.push({"iid" : this.rows[j].pid, "smf" : false});
                else
                    this.smflag.push({"iid" : this.rows[j].pid, "smf" : true});

                if(this.rows[j].overdue == "fiber_manual_record")
                    this.odflag.push({"iid" : this.rows[j].pid, "odf" : false});
                else
                    this.odflag.push({"iid" : this.rows[j].pid, "odf" : true});    
                
                if(this.rows[j].prn == "fiber_manual_record")
                    this.prnflag.push({"iid" : this.rows[j].pid, "prnf" : false});
                else
                    this.prnflag.push({"iid" : this.rows[j].pid, "prnf" : true});                      
            }

            this.pInfo = this.rows.filter(item => item.pid == parseInt(this.patientId))[0];
            this.SMInfo = this.smflag.filter(item => item.iid == parseInt(this.patientId))[0];
            this.ODInfo = this.odflag.filter(item => item.iid == parseInt(this.patientId))[0];
            this.PRNInfo = this.prnflag.filter(item => item.iid == parseInt(this.patientId))[0];

            if(window.location.href.indexOf('#')<0){
                    //if(path!=undefined) {
                        window.location.href=window.location.href+'#'+path;
                    }else{
                        window.location.href=window.location.href;
                    } 
        });
    }






    // project table
    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/projects.json`);
        req.onload = () => {
            cb(JSON.parse(req.response));
        };
        req.send();
    }


    dialogRef2: MdDialogRef<ResponseDialogComponent>;
     
    config2: MdDialogConfig = {
        disableClose: false,
        width: '',
        height: '',
        position: {
            top: '',
            bottom: '',
            left: '',
            right: ''
        }
    };
  

    dialogRef: MdDialogRef<JazzDialogComponent>;
    lastCloseResult: string;
    config: MdDialogConfig = {
        disableClose: false,
        width: '',
        height: '',
        position: {
            top: '',
            bottom: '',
            left: '',
            right: ''
        }
    };

    dialogRef1: MdDialogRef<NComponent>;
    lastCloseResult1: string;
    config1: MdDialogConfig = {
        disableClose: false,
        width: '',
        height: '',
        position: {
            top: '',
            bottom: '',
            left: '',
            right: ''
        }
    };


    constructor(public dialog: MdDialog, public dialog1: MdDialog, public dialog2: MdDialog, private _route: ActivatedRoute) { }




    ResponseOpen() {
        this.dialogRef2 = this.dialog.open(ResponseDialogComponent, this.config2);
        this.dialogRef2.afterClosed().subscribe(result => {      
           this.dialogRef2 = null;
        });
    }


    open() {
        this.dialogRef = this.dialog.open(JazzDialogComponent, this.config);
        this.dialogRef.afterClosed().subscribe(result => {
            this.lastCloseResult = result;
            this.dialogRef = null;
        });
    }

pop() {
    this.dialogRef1 = this.dialog1.open(NComponent, this.config1);
    this.dialogRef1.afterClosed().subscribe(result => {
        this.lastCloseResult1 = result;
        this.dialogRef1 = null;
    });
}
}
@Component({
    selector: 'app-jazz-dialog',
    templateUrl: './HTMLpage1.html'
})
export class JazzDialogComponent implements OnInit {
    currentDrink: string;
    startAt: string;
    hello: string;

    patientName: string;
    patientId: string;
    isRequired = false;
    isDisabled = false;
     
    temp = [];
    rows = [];
    pInfo = [];


    ngOnInit(): void {
        let id = +this._route.snapshot.params['pid'];

        this.patientId = `${id}`;
        console.log("pid", this.patientId);

        this.fetch((data) => {
            this.temp = data;

            this.rows = data;

            this.pInfo = this.rows.filter(item => item.pid == parseInt(this.patientId))[0];
           
        });
    }






    // project table
    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/projects.json`);
        req.onload = () => {
            cb(JSON.parse(req.response));
        };
        req.send();
    }

    
    constructor(public dialogRef: MdDialogRef<JazzDialogComponent>, private _route: ActivatedRoute) { }
    drugs = [{
         
        Route:'A'
    }, {
            Route: 'B'
        }, {
            Route:'C'
    }, {
            Route:'D'
    }
    ];
}


@Component({
    templateUrl: './HTMLpage2.html'
    
})


export class NComponent {
    constructor(public dialogRef1: MdDialogRef<NComponent>) { }

    D8: string;
    startAt: string;

    drugs = [{
         
        Route: 'MEDICATION HELD'
    }, {
        Route: 'HIU'
    }, {
        Route: 'DISCHARGED'
    }, {
        Route: 'D'
    }
    ];
}




@Component({
    templateUrl:'./Response.html'
})
 
export class ResponseDialogComponent {
    Reason: string;

    constructor(public dialogRef2: MdDialogRef<ResponseDialogComponent>) { }

    pResponse = [{

        reason: 'Pain Relived'
    }, {
            reason: 'Anxiety Relived'
    }, {
            reason: 'Remain in Pain'
    }, {
            reason: 'Still Anxious'
    }, {
            reason:'Tolerated Well'
    }
    ];




}



