﻿import { Routes } from '@angular/router';

import { HiComponent } from './wii.component';

export const WiisRoutes: Routes = [{
    path: '',
    component: HiComponent
}];
