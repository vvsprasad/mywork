var crypto = require('crypto')

// getDiffieHellman
exports.DiffieHellmanGroup = crypto.DiffieHellmanGroup
exports.createDiffieHellmanGroup = crypto.createDiffieHellmanGroup
exports.getDiffieHellman = crypto.getDiffieHellman

// createDiffieHellman
exports.createDiffieHellman = crypto.createDiffieHellman
exports.DiffieHellman = crypto.DiffieHellman
