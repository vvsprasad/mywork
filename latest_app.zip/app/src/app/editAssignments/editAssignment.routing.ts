﻿import { Routes } from '@angular/router';

import { EditAssignmentComponent } from './editAssignment.component';
 
export const EaRoutes : Routes = [{
    path: '',
     
        component: EditAssignmentComponent

    
}];
