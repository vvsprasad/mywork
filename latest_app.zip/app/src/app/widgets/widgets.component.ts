﻿import { Component } from '@angular/core';

@Component({
  selector: 'app-widgets',
  templateUrl: './widgets.component.html',
  styleUrls: ['./widgets.component.scss']
})
export class WidgetsComponent {

    rows = [];
    temp = [];

    columns = [
        { name: 'Room' },
        { name: 'Patientname' },
        { name: 'DOB' },
        { name: 'Diagnosis' },
        { name: 'Codestatus' },
        { name: 'LOC' },
        { name: 'Admitdate' },
        { name: 'Recertdue' },
        {name:'Physician'}
    ];

    constructor() {
        this.fetch((data) => {
            this.temp = data;
            this.rows = data;
        });
    }

    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/company.json`);

        req.onload = () => {
            const data = JSON.parse(req.response);
            cb(data);
        };

        req.send();
    }
    updateFilter(event) {
        console.log(event.target.value);
        const val = event.target.value.toLowerCase();

        // filter our data
        const temp = this.temp.filter(function (d) {
            return d.patientname.toLowerCase().indexOf(val) !== -1 || !val;
        });

        // update the rows
        this.rows = temp;
    }
    getRowClass(row) {
        return {
            'text-align': 'center'
        };
    }

}
