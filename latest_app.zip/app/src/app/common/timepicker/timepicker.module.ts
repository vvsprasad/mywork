﻿import { NgModule } from '@angular/core';

import { TimepickerComponent } from './timepicker.component';

@NgModule({
  imports: [],
  declarations: [TimepickerComponent] 
})

export class TimepickerModule {}