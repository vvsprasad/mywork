﻿import { Routes } from '@angular/router';

import { PatientInfoComponent } from './patientInfo.component';

export const PatientInfoRoutes: Routes = [{
    path: '',
    component: PatientInfoComponent
}];
