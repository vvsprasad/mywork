﻿import { Component, OnInit,Input } from '@angular/core';
import { MdDialog, MdDialogRef, MdDialogConfig } from '@angular/material';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable } from 'rxjs/Observable';

@Component({
    selector: 'app-tabs',
    templateUrl: './patientInfo.html',
     
})





export class PatientInfoComponent implements OnInit {
    temp = [];
    rows = [];
    patientId: string;
    pInfo = [];
    columnName: string;
    activeTabId: string;
   

    constructor(private router: Router, private _route: ActivatedRoute, public dialog: MdDialog, public dialog1: MdDialog) {
        this.asyncTabs = Observable.create((observer: any) => {
            setTimeout(() => {
                observer.next(this.tabs);
            }, 1000);
        });
        // Initialize the index by checking if a tab link is contained in the url.
        // This is not an ideal check and can be removed if routerLink exposes if it is active.
        // https://github.com/angular/angular/pull/12525
       this.activeLinkIndex = this.tabLinks.indexOf(this.tabLinks.find(tab => router.url.indexOf(tab.link) !== -1));
    }

    ngOnInit(): void {

        let id = +this._route.snapshot.params['pid'];
        this.patientId = `${id}`;
        let tabid = +this._route.snapshot.params['tabid'];
        this.activeTabId = `${tabid}`;

        this.fetch((data) => {
            this.temp = data;

            this.rows = data;

            this.pInfo = this.rows.filter(item => item.pid == parseInt(this.patientId))[0];
        });
        
    }
    
    // project table
    fetch(cb) {
        const req = new XMLHttpRequest();
        req.open('GET', `assets/data/projects.json`);
        req.onload = () => {
            cb(JSON.parse(req.response));
        };
        req.send();
    }

    // Nav bar demo
    tabLinks = [{
        label: 'Sun',
        link: 'sunny-tab'
    }, {
        label: 'Rain',
        link: 'rainy-tab'
    }, {
        label: 'Fog',
        link: 'foggy-tab'
    }];
  activeLinkIndex = 0;

    // Standard tabs demo
    tabs = [{
        label: 'OverDue ',
        tab1Content: true,
        content: '',
        tabid:0
       
       
    }, {
            label: 'PRN Response',
            tab2Content: true,
            tabid: 1
         
       // content: 'PRN Response will be taken here'
    }, {
            label: 'Schedule Medication',
            tab3Content: true,
            tabid:2
      // extraContent: true,
      //  content: 'Schedule Medication Details will be displayed here'
    }, {
            label: 'PRN',
            tab4Content: true,
            tabid: 3
      //  content: 'This is the body of the fourth tab'
    }];

    // Dynamic tabs demo
    activeTabIndex = 0;
    addTabPosition = 0;
    gotoNewTabAfterAdding = false;
    createWithLongContent = false;
    dynamicTabs = [{
        label: 'Tab 1',
        content:" <history> annad</history> "
    }, {
        label: 'Tab 2',
        disabled: true,
        content: 'This is the body of the second tab'
    }, {
        label: 'Tab 3',
        extraContent: true,
        content: 'T'
    }, {
        label: 'Tab 4',
        content: 'This is the body of the fourth tab'
    }];

    asyncTabs: Observable<any>;
   

    addTab(includeExtraContent: boolean): void {
        this.dynamicTabs.splice(this.addTabPosition, 0, {
            label: 'New Tab ' + (this.dynamicTabs.length + 1),
            content: 'New tab contents ' + (this.dynamicTabs.length + 1),
            extraContent: includeExtraContent
        });
        if (this.gotoNewTabAfterAdding) {
            this.activeTabIndex = this.addTabPosition;
        }
    }

    deleteTab(tab: any) {
        this.dynamicTabs.splice(this.dynamicTabs.indexOf(tab), 1);
    }

    dialogRef: MdDialogRef<JazzDialogComponent>;
    lastCloseResult: string;
    config: MdDialogConfig = {
        disableClose: false,
        width: '',
        height: '',
        position: {
            top: '',
            bottom: '',
            left: '',
            right: ''
        }
    };

    dialogRef1: MdDialogRef<NComponent>;
    lastCloseResult1: string;
    config1: MdDialogConfig = {
        disableClose: false,
        width: '',
        height: '',
        position: {
            top: '',
            bottom: '',
            left: '',
            right: ''
        }
    };


  
    open() {
        this.dialogRef = this.dialog.open(JazzDialogComponent, this.config);
        this.dialogRef.afterClosed().subscribe(result => {
            this.lastCloseResult = result;
            this.dialogRef = null;
        });
    }

    pop() {
        this.dialogRef1 = this.dialog1.open(NComponent, this.config1);
        this.dialogRef1.afterClosed().subscribe(result => {
            this.lastCloseResult1 = result;
            this.dialogRef1 = null;
        });
    }
  

}
@Component({
    selector: 'app-jazz-dialog',
    templateUrl: './HTMLpage1.html'
})
export class JazzDialogComponent {
    currentDrink: string;
    startAt: string;
    hello: string;

    constructor(public dialogRef: MdDialogRef<JazzDialogComponent>) { }
    drugs = [{

        Route: 'A'
    }, {
        Route: 'B'
    }, {
        Route: 'C'
    }, {
        Route: 'D'
    }
    ];
}


@Component({
    templateUrl: './HTMLpage2.html'

})


export class NComponent {
    constructor(public dialogRef1: MdDialogRef<NComponent>) { }

    D8: string;
    startAt: string;

    drugs = [{

        Route: 'MEDICATION HELD'
    }, {
        Route: 'HIU'
    }, {
        Route: 'DISCHARGED'
    }, {
        Route: 'D'
    }
    ];
}

