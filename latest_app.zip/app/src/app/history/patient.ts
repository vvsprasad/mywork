﻿export interface IPatient {
   


    room: string,
    patientname: string,
    project: string,
    date: string,
    progress: number,
    time: string,
    one: string,
    two: string,
    overdue: string,
    pid: string,
    dob: string
}