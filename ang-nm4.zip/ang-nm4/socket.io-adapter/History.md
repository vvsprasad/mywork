
0.5.0 / 2016-11-20
==================

  * [docs] Fix typo in Readme.md (#37)
  * [chore] Bump socket.io-parser to version 2.3.1 (#43)
  * [chore] Bump debug to version 2.3.3 (#42)
  * [feature] Add clientRooms method (#41)

0.4.0 / 2015-12-03
==================

  * package: bump `debug`
  * use a `Room` class to efficiently track room size
  * allow `clients(fn)`
  * call the callback on `delAll`

0.3.1 / 2014-10-27
==================

 * bump parser version
 * fix room autopruning
 * add autoprunning of empty rooms
 * rooms are now created as objects
 * added the repository field.
 * updated the debug dependency.

0.3.0 / 2014-05-30
==================

 * bump `socket.io-parser` for binary ack fix

0.2.0 / 2014-03-14
==================

 * upgraded faster parser

0.1.0 / 2014-03-07
==================

 * initial commit
