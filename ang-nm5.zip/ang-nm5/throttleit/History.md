
1.0.0 / 2015-02-27
==================

 - Internal refactor
 - Removed `max` argument
 - Context for invocation is cached/cleared properly
 - More tests

0.0.2 / 2013-03-26
==================

 - Cache the return value
 - Don't use `setTimeout()`

0.0.1 / 2013-03-26
==================

 - Initial release
