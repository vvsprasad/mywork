require('./').register({
  lazy: true
})
