
var config = {
	database: {
		url: 'mongodb://localhost:27017/ketan'
	},
	server: {
		host: '127.0.0.1',
		port: '3000'
	}
}

module.exports = config
