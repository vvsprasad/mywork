"use strict";
var Observable_1 = require('../../Observable');
var elementAt_1 = require('../../operator/elementAt');
Observable_1.Observable.prototype.elementAt = elementAt_1.elementAt;
//# sourceMappingURL=elementAt.js.map