"use strict";
var Observable_1 = require('../../Observable');
var isEmpty_1 = require('../../operator/isEmpty');
Observable_1.Observable.prototype.isEmpty = isEmpty_1.isEmpty;
//# sourceMappingURL=isEmpty.js.map