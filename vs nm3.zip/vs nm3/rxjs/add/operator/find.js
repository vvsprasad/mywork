"use strict";
var Observable_1 = require('../../Observable');
var find_1 = require('../../operator/find');
Observable_1.Observable.prototype.find = find_1.find;
//# sourceMappingURL=find.js.map