var harness_1 = require('./harness');
var spec = require("./spec");
var results = harness_1.runTests(spec);
harness_1.printResults(results);
//# sourceMappingURL=run.js.map