A list of objects, bound by their prototype chain.

Used in npm's config stuff.
