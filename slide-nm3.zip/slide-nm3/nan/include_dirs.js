console.log(require('path').relative('.', __dirname));
