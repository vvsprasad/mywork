
var agGrid = require('../../docs/dist/ag-grid.js');
var stringify = require('json-stable-stringify');

describe('columnController', function() {

/*    it('simple flatten', function() {

        var columnFlattener = new ag.grid.ColumnFlattener();

        var input = [
            {field: "a"},
            {field: "b"},
            {field: "c"},
            {children: [
                {field: "d"},
                {field: "e"}
            ]}
        ];

        var expected = [
            {children: [
                {field: "a"},
                {field: "b"},
                {field: "c"}
            ]},
            {children: [
                {field: "d"},
                {field: "e"}
            ]}
        ];

        var actual = columnFlattener.padHierarchy(input);

        expect(stringify(expected)).toEqual(stringify(actual));
    });*/

});
