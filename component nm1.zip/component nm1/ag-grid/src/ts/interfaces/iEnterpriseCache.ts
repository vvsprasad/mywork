
export interface IEnterpriseCache {

}
