require('../modules/core.number.iterator');
module.exports = require('../modules/_core').Number;