require('../modules/es6.parse-float');
module.exports = require('../modules/_core').parseFloat;