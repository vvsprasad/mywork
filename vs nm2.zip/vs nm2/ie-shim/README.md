# ie-shim
ie-shim for Angular 2

