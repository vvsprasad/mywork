/// <reference types="whatwg-fetch" />
export declare function fetch(url: string | Request, init?: RequestInit): Promise<any>;
export { baseUrl } from './main';
