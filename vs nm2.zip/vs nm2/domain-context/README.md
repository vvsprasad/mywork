Globally accessible domain-bound contexts, connect/express middleware included,
see [docs](http://andreypopp.github.io/domain-context/).
