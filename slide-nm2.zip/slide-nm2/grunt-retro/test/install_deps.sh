npm uninstall $REMOVE_DEPS
npm install $DEPS