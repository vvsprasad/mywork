# grunt-retro changelog
0.6.4 - Added Travis CI integration

Before 0.6.4 - See `git log`