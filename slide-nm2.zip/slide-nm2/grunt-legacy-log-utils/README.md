# grunt-legacy-log
> Static methods for the Grunt 0.4.x logger.

[![Build Status](https://secure.travis-ci.org/gruntjs/grunt-legacy-log-utils.png?branch=master)](http://travis-ci.org/gruntjs/grunt-legacy-log-utils)
[![Built with Grunt](https://cdn.gruntjs.com/builtwith.png)](http://gruntjs.com/)

