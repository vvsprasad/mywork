# getobject [![Build Status](https://secure.travis-ci.org/cowboy/node-getobject.png?branch=master)](http://travis-ci.org/cowboy/node-getobject)

get.and.set.deep.objects.easily = true;

## Getting Started
Install the module with: `npm install getobject`

```javascript
var getobject = require('getobject');
```

## Contributing
In lieu of a formal styleguide, take care to maintain the existing coding style. Add unit tests for any new or changed functionality. Lint and test your code using [Grunt](http://gruntjs.com/).

## Release History
_(Nothing yet)_

## License
Copyright (c) 2013 "Cowboy" Ben Alman
Licensed under the MIT license.