# Grunt: The JavaScript Task Runner

[![Build Status: Linux](https://secure.travis-ci.org/gruntjs/grunt.png?branch=master)](http://travis-ci.org/gruntjs/grunt)
<a href="https://ci.appveyor.com/project/gruntjs/grunt"><img src="https://ci.appveyor.com/api/projects/status/32r7s2skrgm9ubva/branch/master" alt="Build Status: Windows" height="18" /></a>
[![Built with Grunt](https://cdn.gruntjs.com/builtwith.png)](http://gruntjs.com/)

<img align="right" height="260" src="http://gruntjs.com/img/grunt-logo-no-wordmark.svg">


### Documentation

Visit the [gruntjs.com](http://gruntjs.com/) website for all the things.

### Support / Contributing
Before you make an issue, please read our [Contributing](http://gruntjs.com/contributing) guide.

You can find the grunt team in [#grunt on irc.freenode.net](http://webchat.freenode.net/?channels=grunt).

### Release History
See the [CHANGELOG](CHANGELOG).
