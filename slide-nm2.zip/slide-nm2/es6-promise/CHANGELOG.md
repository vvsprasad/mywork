# Master

# 2.0.0

* re-sync with RSVP. Many large performance improvements and bugfixes.

# 1.0.0

* first subset of RSVP
