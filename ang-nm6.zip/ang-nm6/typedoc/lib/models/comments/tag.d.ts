export declare class CommentTag {
    tagName: string;
    paramName: string;
    text: string;
    constructor(tagName: string, paramName?: string, text?: string);
    toObject(): any;
}
