import { ConverterComponent } from "../components";
export declare class DeepCommentPlugin extends ConverterComponent {
    initialize(): void;
    private onBeginResolve(context);
}
