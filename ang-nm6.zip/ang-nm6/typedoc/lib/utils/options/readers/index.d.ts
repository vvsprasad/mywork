export { ArgumentsReader } from "./arguments";
export { TSConfigReader } from "./tsconfig";
export { TypedocReader } from "./typedoc";
