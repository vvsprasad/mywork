export declare function ifCond(v1: any, operator: any, v2: any, options: any): any;
