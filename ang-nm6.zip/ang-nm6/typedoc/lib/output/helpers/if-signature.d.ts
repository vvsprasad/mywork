export declare function ifSignature(obj: any, arg: any): any;
