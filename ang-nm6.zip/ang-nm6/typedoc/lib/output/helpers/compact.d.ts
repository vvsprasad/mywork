export declare function compact(options: any): string;
