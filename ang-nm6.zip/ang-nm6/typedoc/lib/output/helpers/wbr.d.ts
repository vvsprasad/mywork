export declare function wbr(options: any): string;
