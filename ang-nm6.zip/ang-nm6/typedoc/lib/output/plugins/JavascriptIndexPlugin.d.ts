import { RendererComponent } from "../components";
export declare class JavascriptIndexPlugin extends RendererComponent {
    initialize(): void;
    private onRendererBegin(event);
}
