import { RendererComponent } from "../components";
export declare class AssetsPlugin extends RendererComponent {
    copyDefaultAssets: boolean;
    initialize(): void;
    private onRendererBegin(event);
}
