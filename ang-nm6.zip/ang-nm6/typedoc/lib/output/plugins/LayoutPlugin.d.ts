import { RendererComponent } from "../components";
export declare class LayoutPlugin extends RendererComponent {
    initialize(): void;
    private onRendererEndPage(page);
}
