export declare class UrlMapping {
    url: string;
    model: any;
    template: string;
    constructor(url: string, model: any, template: string);
}
