/**
 * @license
 * Copyright Google Inc. All Rights Reserved.
 *
 * Use of this source code is governed by an MIT-style license that can be
 * found in the LICENSE file at https://angular.io/license
 */
export var FILL_STYLE_FLAG = 'true'; // TODO (matsko): change to boolean
export var ANY_STATE = '*';
export var DEFAULT_STATE = '*';
export var EMPTY_STATE = 'void';
//# sourceMappingURL=animation_constants.js.map