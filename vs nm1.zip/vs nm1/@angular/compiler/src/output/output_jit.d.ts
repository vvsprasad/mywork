import * as o from './output_ast';
export declare function jitStatements(sourceUrl: string, statements: o.Statement[], resultVar: string): any;
