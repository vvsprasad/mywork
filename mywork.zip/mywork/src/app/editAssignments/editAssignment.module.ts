﻿import { NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { EditAssignmentComponent, JazzDialogComponent } from './editAssignment.component';
import { EaRoutes } from './editAssignment.routing';
import { NgxDatatableModule } from '@swimlane/ngx-datatable';
import { MdButtonToggleModule, MdInputModule} from '@angular/material';
import { FormControl   } from '@angular/forms';
import { MdIconModule, MdCardModule, MdButtonModule, MdListModule, MdProgressBarModule, MdMenuModule, MdSelectModule } from '@angular/material';
import { FlexLayoutModule } from '@angular/flex-layout';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpModule } from '@angular/http';
 import {
    FullscreenOverlayContainer,
    MaterialModule,
    MdNativeDateModule,
    MdSelectionModule,
    OverlayContainer
} from '@angular/material';
  

@NgModule({
    imports: [
        CommonModule,
        RouterModule.forChild(EaRoutes),
        NgxDatatableModule,
        MdButtonModule,
        MdButtonToggleModule,
        MdIconModule,
        MdInputModule,
        MdSelectionModule,
        MdSelectModule,
        MaterialModule,
        MdNativeDateModule,
        
        HttpModule,
        FormsModule,
        ReactiveFormsModule,
        FlexLayoutModule,
        
     
       
        

    ],
    providers: [
        { provide: OverlayContainer, useClass: FullscreenOverlayContainer }
    ],


    declarations: [EditAssignmentComponent, JazzDialogComponent],
    entryComponents: [JazzDialogComponent]
     
   
})

export class EaModule { }
