declare function pascalCase (value: string, locale?: string, mergeNumbers?: boolean): string;

export = pascalCase;
