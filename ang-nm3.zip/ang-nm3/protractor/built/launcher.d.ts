import { Config } from './configParser';
export declare let init: (configFile: string, additionalConfig: Config) => void;
