/// <reference path="main/ambient/chalk/index.d.ts" />
/// <reference path="main/ambient/form-data/index.d.ts" />
/// <reference path="main/ambient/glob/index.d.ts" />
/// <reference path="main/ambient/minimatch/index.d.ts" />
/// <reference path="main/ambient/node/index.d.ts" />
/// <reference path="main/ambient/optimist/index.d.ts" />
/// <reference path="main/ambient/q/index.d.ts" />
/// <reference path="main/ambient/request/index.d.ts" />
