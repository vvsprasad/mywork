declare function paramCase (value: string, locale?: string): string;

export = paramCase;
