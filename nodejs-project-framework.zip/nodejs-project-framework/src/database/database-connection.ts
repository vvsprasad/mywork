import Config from '../config/config';

//Import the mongoose module
const mongoose = require('mongoose');

//Set up default mongoose connection
mongoose.connect(Config.MONGO_URI, { useNewUrlParser: true });

//Get the default connection
const db = mongoose.connection;

//Bind connection to error event (to get notification of connection errors)
db.on('error', console.error.bind(console, 'MongoDB connection error:'));

// mongoose.set('debug', function (collection, method, query, doc) {
//     console.log("collection",collection);
//     console.log("method",method);
//     console.log("query",query);
//     console.log("doc",doc);
// });

export default db;