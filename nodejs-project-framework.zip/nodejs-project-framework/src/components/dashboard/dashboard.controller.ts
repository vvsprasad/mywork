import TransactionRepository from '../../repository/TransactionRepository';

import BaseController from '../../shared/BaseController';

const transactionRepository = new TransactionRepository()

var userId;
class DashboardController extends BaseController {
    async createTransactionDetails(request, response, next) {

        const params = request.body;
        const tranasactionDetails = await transactionRepository.createMeeting(params);

        // const tranasactionDetails = await transactionRepository.getTransactionDetails(params.order_no);

        let condition = {};
        const total_count = await transactionRepository.count_records(condition);
        let details = { "transaction_data": tranasactionDetails, "total_records": total_count };
        return this.sendResponse(response, true, 200, { details }, "Transaction Created Successfully");
    }

    async getTransactionDetails(request, response, next) {

        const params = request.body;

        const tranasactionDetails = await transactionRepository.getTransactionDetails(params.order_no);

        let condition = {};
        const total_count = await transactionRepository.count_records(condition);
        let details = { "transaction_data": tranasactionDetails, "total_records": total_count };
        if (details['transaction_data'] != '') {
            return this.sendResponse(response, true, 200, { details }, "Records Fetch Successfully");
        }
        else {
            return this.sendResponse(response, false, 404, '', "No Data Found");

        }

    }

    async deleteTransactionDetails(request, response, next) {

        const params = request.body;
        let condition1 = { "order_no": params.order_no }

        const tranasactionDetails = await transactionRepository.deleteTransaction(condition1);

        let condition = {};
        const total_count = await transactionRepository.count_records(condition);
        let details = { "transaction_data": tranasactionDetails, "total_records": total_count };
        if (details['transaction_data'] != '') {
            return this.sendResponse(response, true, 200, { details }, "Deleted Successfully");
        }
        else {
            return this.sendResponse(response, false, 404, '', "No Data Found");

        }

    }

    async updateTransaction(request, response, next) {

        const params = request.body;
        const tranasactionDetails = await transactionRepository.updateTransaction(params);

        let condition = {};
        const total_count = await transactionRepository.count_records(condition);
        let details = { "transaction_data": tranasactionDetails, "total_records": total_count };
        if (details['transaction_data'] != '') {
            return this.sendResponse(response, true, 200, { details }, "Updated Successfully");
        }
        else {
            return this.sendResponse(response, false, 404, '', "No Data Found");

        }

    }







}

export default DashboardController;