import * as express from 'express';

import DashboardController from './dashboard.controller';


const dashboardController = new DashboardController();

let router = express();


router.post('/create', (req, res, next) => {
    dashboardController.createTransactionDetails(req, res, next);
});


router.post('/list', (req, res, next) => {
    dashboardController.getTransactionDetails(req, res, next);
});


router.post('/delete', (req, res, next) => {
    dashboardController.deleteTransactionDetails(req, res, next);
});

router.post('/update', (req, res, next) => {
    dashboardController.updateTransaction(req, res, next);
});



export default router;