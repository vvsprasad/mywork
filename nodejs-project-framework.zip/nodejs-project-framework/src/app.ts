// import * as error from './shared/middlewares/error';
import * as bodyParser from 'body-parser';
import * as compression from 'compression';
import * as cors from 'cors'
import * as express from 'express';
import router from './route';
import BaseController from './shared/BaseController';

class App extends BaseController {
    public app;

    constructor() {
        super();
        this.initApp();
    }
    
    public initApp() {

        this.app = express();
    
        /**
         * Enable compression
         */
        this.app.use(compression({
            threshold: 0,
            filter: function () {
                return true;
            }
        }));

        this.app.use(bodyParser.json({
            limit: '20mb'
        }));

        this.app.use(bodyParser.urlencoded({
            limit: '20mb',
            extended: true
        }));

        this.app.use(cors());
        this.app.use('/api', router);
        
        this.app.get("/", function (req, res) {
            res.status(200).send({ message: 'Welcome to our restful API' });
        });
        
        // this.app.use(error);
        
        const server = this.app.listen(8084, function (err, req, res, next) {
            const port = server.address().port;
            console.log(`server started at http://localhost:${port}`);
        });
        server.timeout = 60000 * 5;
    }
}

export default new App();