import * as express from 'express';

import dashboardRouter from './components/dashboard/dashboard.route';


const router = express();



//For dashboard
router.use('/dashboard', dashboardRouter);


export default router;
