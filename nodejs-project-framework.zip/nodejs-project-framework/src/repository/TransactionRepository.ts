import Transaction from '../model/transaction';
import { BaseRepository } from './BaseRepository';


export default class MeetingRepository extends BaseRepository {

    constructor() {
        super(Transaction);
    }

    getTransactionDetails(id: String) {
        return new Promise((resolve, reject) => {
            let condition = { order_no: id };
            console.log("cond", condition);

            this.find(condition, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    resolve(data);
                }
            })
        });
    }


    count_records(condition) {
        return new Promise((resolve, reject) => {
            this.count(condition, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    resolve(data);
                }
            })
        });
    }

    createMeeting(params) {
        return new Promise((resolve, reject) => {
            params.order_no = params.order_no;
            params.order_type = params.order_type;
            params.datetime = params.datetime;
            params.total_products = params.total_products;
            params.total_adjustments = params.total_adjustments;
            this.create(params, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    resolve(data);
                }
            })
        });
    }


    deleteTransaction(condition) {
        return new Promise((resolve, reject) => {
            this.deleteMany(condition, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    resolve(data);
                }
            })
        });
    }

    updateTransaction(params: any) {
        return new Promise((resolve, reject) => {
            let paramsUpdate: any = {};
            let _id = params._id;
            paramsUpdate.order_type = params.order_type;
            this.updateOne(_id, paramsUpdate, function (error, data) {
                if (error) {
                    reject(error);
                } else {
                    resolve(data);
                }
            })
        });
    }



}
