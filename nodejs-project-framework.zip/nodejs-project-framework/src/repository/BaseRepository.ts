import * as mongoose from 'mongoose';

const mongoConnect = require('../database/database-connection');

export class BaseRepository {
  private _model: mongoose.Model;

  constructor(schemaModel: mongoose.Model) {
    this._model = schemaModel;
  }

  create(item: any, callback: (error: any, result: any) => void) {
    this._model.create(item, callback);
  }

  insertMany(item: any, callback: (error: any, result: any) => void) {
    this._model.insertMany(item, callback);
  }

  findOne(cond?: Object, fields?: Object, callback?: (err: any, res: any) => void): mongoose.Query<any> {
    return this._model.findOne(cond, fields, callback);
  }
  
  findOneById(_id: mongoose.Types.ObjectId, fields?: Object, callback?: (err: any, res: any) => void): mongoose.Query<any> {
    return this._model.findOne({ _id: _id }, fields, callback);
  }

  find(cond?: Object, fields?: Object, options?: Object, callback?: (err: any, res: any) => void): mongoose.Query<any> {
    return this._model.find(cond, fields, options, callback);
  }

  updateOne(_id: mongoose.Types.ObjectId, item: any, callback: (error: any, result: any) => void) {
    this._model.updateOne({ _id: _id }, item, callback);
  }

  updateMany(cond: Object, item: any, callback: (error: any, result: any) => void) {
    this._model.updateMany(cond, item, callback);
  }

  count(cond?: Object, callback?: (err: any, res: any) => void): mongoose.Query<any> {
    return this._model.count(cond, callback);
  }

  distinct(field?: string, cond?: Object, callback?: (err: any, res: any) => void): mongoose.Query<any> {
    return this._model.distinct(field, cond, callback);
  }

  update(cond?: Object, fields?: Object, callback?: (err: any, res: any) => void): mongoose.Query<any> {
    return this._model.updateMany(cond, fields, { upsert: true }, callback);
  }

  countDocuments(cond?: Object, callback?: (err: any, res: any) => void): mongoose.Query<any> {
    return this._model.countDocuments(cond, callback);
  }

  deleteMany(cond: Object, callback?: (error: any, result: any) => void) {
    this._model.deleteMany(cond, callback);
  }
}