// Setup config based on environment 
export default {
    // Development environment config 
    "dev": {
        "MONGO_URI": "mongodb://localhost/rodigro"
    },
    // Production environment config 
    "prod": {
        "MONGO_URI": "mongodb://localhost/rodigro"
    },
  
}