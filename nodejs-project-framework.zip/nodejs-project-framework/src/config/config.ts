import env from './env';
require('dotenv').config();
export default env[process.env.NODE_ENV];