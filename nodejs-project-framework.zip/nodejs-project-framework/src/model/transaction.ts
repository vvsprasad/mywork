const mongoose = require('mongoose');

const Schema = mongoose.Schema;

export const TransactionSchema = new Schema({
    order_no: { type: Number },
    datetime: { type: Date},
    total_products: { type: Number },
    total_adjustments : {type : Number},
    order_type : {type : String}
})

const Transaction = mongoose.model('Transaction', TransactionSchema);

export default Transaction;